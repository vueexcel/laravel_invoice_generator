<!DOCTYPE html>
<html>
<head>
    <title>Demo Email</title>
</head>
<body>
    <p>{{ $data['message'] }}</p>
</body>
</html>
