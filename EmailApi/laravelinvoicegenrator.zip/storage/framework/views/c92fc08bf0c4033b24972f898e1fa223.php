<!DOCTYPE html>
<html>
<head>
    <title>Email Sending Form</title>
</head>
<body>
    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <form method="POST" action="/api/send-email" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="to">To:</label>
        <input type="email" name="to" required><br>
        <label for="message">Message:</label><br>
        <textarea name="message" required></textarea><br>
        <label for="attachment">Attachment (PDF only):</label>
        <input type="file" name="attachment" accept=".pdf" required><br>
        <button type="submit">Send Email</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\invoicegenerator\EmailApi\resources\views/email-form.blade.php ENDPATH**/ ?>