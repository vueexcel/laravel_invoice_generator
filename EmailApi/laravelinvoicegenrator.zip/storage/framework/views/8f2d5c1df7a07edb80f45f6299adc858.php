<!DOCTYPE html>
<html>
<head>
    <title>Demo Email</title>
</head>
<body>
    <p><?php echo e($data['message']); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\invoicegenerator\EmailApi\resources\views/emails/demo.blade.php ENDPATH**/ ?>